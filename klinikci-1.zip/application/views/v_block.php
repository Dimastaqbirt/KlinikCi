<div class="container-fluid vh-100 bg-light">
    <div class="row justify-content-center align-items-center vh-100">
        <div class="col-lg-4 col-md-8">
            <H1 class="text-center">AKSES DIBLOK</H1>
            <p class="text-center">Silahkan Hubungi Developer</p>
            <img src="<?= base_url('assets/images/eror.png') ;?>" alt="" class="img-fluid">
        </div>
    </div>
</div>